package Poly;
import java.util.*;


public class ShapeDemo{
    /**
     *
     * @param args
     * our main driver class that takes user input and sends it into our independent methods to be calculated..
     */
    public static void main(String args[]){
        Scanner scan = new Scanner(System.in);
        String P, A;
        P = ("The perimeter is: ");
        A = ("The area is: ");

        //Square
        System.out.println("Enter side length of Square: ");
        int sSl = scan.nextInt();
        Polygon getSquare = new Square(sSl);
        System.out.println(P + getSquare.perimeter());
        System.out.println(A + getSquare.area());
        //Rectangle
        System.out.println("Enter base and side length for Rectangle: ");
        int rBl = scan.nextInt();
        int rSl = scan.nextInt();
        Polygon getRectangle = new Rectangle();
        getRectangle.area();
        System.out.println(P + getRectangle.perimeter());
        System.out.println(A);
        //Hexagon
        System.out.println("Enter side length for Hexagon: ");
        int hSl = scan.nextInt();
        Polygon getHexagon = new Hexagon(hSl);
        System.out.println(P + getHexagon.perimeter());
        System.out.println(A + getHexagon.area());






    }
}
