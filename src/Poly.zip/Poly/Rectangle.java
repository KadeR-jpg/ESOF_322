package Poly;

/**
 * @class Rectangle is our main class that
 * will return area and perimeter
 *
 */
public class Rectangle implements Polygon{
    private double A = 0;
    double L, W;

    public double area() {
        A = (L * W);
        return A;

    }

    public double perimeter() {
        double P = 2*(L + W);
        return P;


    }
}
