package Poly;

/**Methods that are required by every use of the interface
 * @area
 * @perimeter
 */
interface Polygon {
    double area();
    double perimeter();
}
