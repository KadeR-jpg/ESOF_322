package Poly;
import java.math.*;

/**
 * @class Hexagon is our main class that will
 * return the area and perimeter of a hexagon
 *
 */

public class Hexagon implements Polygon {
    double A, hSl;

    public double area() {
        A = ((3*(Math.sqrt(3)/2))*(hSl*hSl));
        return A;
    }
    public double perimeter() {
        double peri;
        peri = 6*(hSl);
        return peri;
    }
}
