package Poly;

/**
 * @Class Square will return the area and perimeter of the square
 *
 */
public class Square implements Polygon {
    private double A = 0;
    private  double peri = 0;
    double sSl;

    public double area(){
        double sSl;
        A = (sSl * sSl);
        return A;
    }
    public double perimeter(){
        double sSl, peri;
        peri = 4*(sSl);
        return peri;


    }
}
